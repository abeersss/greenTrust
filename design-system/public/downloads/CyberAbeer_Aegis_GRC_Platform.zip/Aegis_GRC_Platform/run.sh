#!/usr/bin/env bash
cd "$(dirname "$0")"
echo "Starting Aegis GRC at http://127.0.0.1:8700 (Ctrl+C to stop)"
python3 grc_app.py
