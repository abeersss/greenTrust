@echo off
title Build Aegis GRC executable
where python >nul 2>nul
if errorlevel 1 (
  echo Python not found. Install Python 3.10+ first ^(see run.bat^).
  pause
  exit /b
)
echo Installing PyInstaller (one-time, needs internet)...
python -m pip install --upgrade pyinstaller
echo.
echo Building AegisGRC.exe ...
pyinstaller --onefile --name AegisGRC grc_app.py
echo.
echo ============================================================
echo  Done. Your standalone program is here:
echo      dist\AegisGRC.exe
echo
echo  Copy AegisGRC.exe to any Windows machine and double-click.
echo  No Python needed on that machine. The grc.db database is
echo  created in the same folder as the exe on first run.
echo ============================================================
pause
