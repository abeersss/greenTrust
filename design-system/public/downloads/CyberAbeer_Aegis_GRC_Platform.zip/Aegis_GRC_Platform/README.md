# Aegis GRC: a self-hosted Governance, Risk and Compliance platform

Distributed free by CyberAbeer (cyberabeer.com) as part of its practical GRC tools.
This is a real, working application you fully own, not a demo or a trial.

A complete, single-file GRC application: its own database, login with role-based
access, a dashboard with live alerts, and registers for Policies, Risks, Audits,
Audit Findings, ISO/IEC 27001:2022 controls, Business Continuity, Requirements,
Configuration Management and Monitoring. It includes a pluggable AI assistant to
summarise policies and find review gaps.

No third-party libraries. One Python file. Easy to run, easy to turn into an
`.exe`.

---

## 1. Quick start (no build, just run)

You need **Python 3.10+** installed (https://www.python.org/downloads/ - on
Windows tick *"Add python.exe to PATH"*).

- **Windows:** double-click **`run.bat`**. A browser opens at `http://127.0.0.1:8700`.
- **macOS / Linux:** run `./run.sh` (or `python3 grc_app.py`).

Sign in with one of the default accounts (change them after first login):

| Username | Password    | Role                                   |
|----------|-------------|----------------------------------------|
| `admin`  | `Admin@123` | Administrator - full access + users    |
| `auditor`| `Auditor@123`| External Auditor - edit audits/findings, read everything else |
| `qa`     | `Qa@123`    | QA - **read only**, everything          |

The database file `grc.db` is created automatically next to the program.

---

## 2. Make the `.exe` (Windows)

Double-click **`build_exe.bat`**. It installs PyInstaller (needs internet once)
and produces a single standalone program:

```
dist\AegisGRC.exe
```

Copy `AegisGRC.exe` to any Windows PC and double-click it - no Python required on
that machine. `grc.db` is created in the same folder as the exe, so keep them
together (or back the database up by copying that one file).

> The exe must be built **on Windows** to run on Windows - that is a property of
> PyInstaller, not a limitation of this app. The same one command works on macOS
> and Linux to build a native binary there.

---

## 3. What's inside

**Dashboard** - counts, ISO implementation %, top residual risks, and an
**Alerts** panel that flags: overdue policy reviews, high residual risks
(score ≥ 15), overdue risk reviews, overdue audit findings, overdue BCP tests,
and outstanding ISO controls.

**Registers**
- **Policies & Procedures** - full document tracking, versioning, review dates,
  status, AI summary and gap fields, **plus file attachments** (attach the signed
  PDF/Word version of each policy).
- **Risk Register** - likelihood × impact scoring (inherent and residual),
  treatment, owner, review date. Scores are colour-banded red/amber/green and
  drive the dashboard alerts.
- **Audits** (with **file attachments** for reports/evidence) and **Audit
  Findings** (linked by audit reference, with severity and due dates).
- **ISO/IEC 27001:2022** - all **93 Annex A controls** pre-loaded across the four
  themes (Organizational, People, Physical, Technological). Track applicability,
  implementation status, owner and evidence - this is your Statement of
  Applicability working copy.
- **Business Continuity** - plans with RTO/RPO and test scheduling.
- **Compliance Register** - map obligations (ISO, SOC 2, GDPR, contractual…) to
  controls and track whether each is met or a gap.
- **Configuration Management** - config items, baselines, drift/compliance status,
  **plus file attachments** (baseline docs, evidence).
- **Monitoring Requirements** - what must be monitored, by which tool, how often.

**Attachments** - on Policies, Audits and Configuration items you can upload any
file (PDF, Word, etc., up to 25 MB each). Files are stored in an `uploads` folder
next to the program and listed on each record with download and remove buttons.

**Export to Excel** - the **Export to Excel** item in the sidebar (and an "Export"
button on every register) downloads data as real `.xlsx` files: any single
register on its own, or **all registers in one workbook** with a separate sheet
each. All roles can export.

**Administration** - Admins manage users and roles. Every login, create, update,
delete and AI run is written to an internal `audit_log` table.

---

## 4. Roles & permissions

| Capability                         | Admin | External Auditor | QA |
|------------------------------------|:-----:|:----------------:|:--:|
| View all registers & dashboard     |  ✓    |        ✓         | ✓  |
| Create / edit audits & findings    |  ✓    |        ✓         | -  |
| Create / edit all other registers  |  ✓    |        -         | -  |
| Manage users & roles               |  ✓    |        -         | -  |

QA is strictly read-only. The External Auditor role is scoped to audit work so an
outside party can record findings without touching your policies or risk data.

---

## 5. AI / Copilot policy summarisation

Open any **Policy** and click **"Summarise & find gaps"**.

- **Out of the box** (no setup): a built-in offline analysis summarises the
  policy text and flags common gaps - missing owner/version, overdue or
  unevidenced reviews, unapproved status, and missing scope / responsibilities /
  review-cadence / compliance references in the text.
- **With your company's AI service:** an administrator opens **AI / Copilot** in
  the sidebar (under Administration) and fills in the connection your admin
  provides - no environment variables or code needed:

  1. **Provider** - choose *Azure OpenAI* (the service behind Microsoft Copilot),
     *OpenAI*, or *Anthropic*. Leave on *Off* to keep the offline analysis.
  2. **Model / deployment name** - Azure: your deployment name; OpenAI: e.g.
     `gpt-4o-mini`; Anthropic: e.g. `claude-3-5-sonnet-latest`.
  3. **Endpoint URL** - your admin gives you this (Azure looks like
     `https://YOUR-RESOURCE.openai.azure.com/openai/deployments/YOUR-DEPLOYMENT/chat/completions?api-version=2024-02-15-preview`).
     Leave blank for OpenAI/Anthropic defaults.
  4. **API key** - paste it; it is stored in your local database and never shown
     again. Leave blank when re-saving to keep the existing key.

  Click **Save connection**, then **Test connection** to confirm it works. The
  label on each policy switches to "connected AI provider", and the same button
  now uses your service. If a live call ever fails it quietly falls back to the
  offline analysis. Use **Disable & clear** to turn it off and erase the key.

  (Environment variables `GRC_AI_PROVIDER` / `GRC_AI_KEY` / `GRC_AI_ENDPOINT` /
  `GRC_AI_MODEL` still work as an alternative if you prefer; the in-app settings
  take priority.)

**About Microsoft 365 Copilot specifically:** Copilot's chat doesn't expose a
direct "summarise this record" API to a local app - it works through your tenant.
The practical path is the **Azure OpenAI** option above (the same model family
behind Copilot). You can also keep authoring policies here and sync them to the
SharePoint library your M365 Copilot declarative agent uses as a knowledge
source, so Copilot can answer questions across the whole policy set.

---

## 6. Configuration

Set before launch (optional):

| Variable    | Default     | Meaning                          |
|-------------|-------------|----------------------------------|
| `GRC_HOST`  | `127.0.0.1` | bind address (`0.0.0.0` for LAN) |
| `GRC_PORT`  | `8700`      | port                             |
| `GRC_DB`    | `grc.db`    | database file path               |

> Hosting for a team: run on a server with `GRC_HOST=0.0.0.0` behind a reverse
> proxy with HTTPS. The login uses PBKDF2-hashed passwords and HttpOnly session
> cookies; for internet exposure, terminate TLS at the proxy.

---

## 7. Honest scope

This is a real, working foundation you fully own - code and data. It is not a
drop-in replacement for an enterprise suite like RSA Archer (workflow engines,
connectors, and reporting built by large teams over many years). It is designed
to be simple to run today and straightforward to extend: each register is defined
by a short field list near the top of `grc_app.py`, so adding a column or a whole
new register is a few lines. Back up by copying `grc.db` **and** the `uploads`
folder (which holds your attached documents).
