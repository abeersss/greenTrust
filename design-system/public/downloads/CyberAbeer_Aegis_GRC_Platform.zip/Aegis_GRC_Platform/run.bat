@echo off
title Aegis GRC
where python >nul 2>nul
if errorlevel 1 (
  echo.
  echo Python was not found.
  echo Install Python 3.10 or newer from https://www.python.org/downloads/
  echo IMPORTANT: tick "Add python.exe to PATH" during install, then run this again.
  echo.
  pause
  exit /b
)
echo Starting Aegis GRC...  (a browser tab will open)
echo Close this window to stop the application.
start "" http://127.0.0.1:8700
python grc_app.py
pause
